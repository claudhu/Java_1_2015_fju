package test;

import java.util.Scanner;

public class Lottery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner input = new Scanner(System.in);
	
   System.out.println("Please enter the number:");
	int a = input.nextInt();
	System.out.println("Sorry!");
	for(int i = 1 ;i<=a;i++){
	  for(int j=1 ; j<=0;j++){
       System.out.print("a");
	   System.out.println();
	   
	  }
	for(int j=a ; j>1; j++){
	System.out.print("b");
	}
	System.out.println();
	
	
	
	
	}
	}

}
