
public class Converter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.Scanner input = new java.util.Scanner(System.in);
		System.out.print("enter kilogram:");
		double kg = input.nextDouble();
		double pound = kg*2.20462;
		System.out.print("pound=" + pound);
	
		
	}

}
