package ex8;
import java.util.Scanner;
public class OneTicket {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner input = new Scanner(System.in);
	System.out.println("�п�J�����N�X (1~5) : ");
	int ticket = input.nextInt();
	System.out.println("�п�J�ƶq: ");
	int amount = input.nextInt();
	
	int Prize = 0;
	switch(ticket){
	case 1 : System.out.println("Prize: "+amount*3000);
	break;
	case 2 : System.out.println("Prize: "+amount*2500);
	break;
	case 3 : System.out.println("Prize: "+amount*2000);
	break;
	case 4 : System.out.println("Prize: "+amount*1500);
	break;
	case 5 : System.out.println("Prize: "+amount*500);
	
	
	
	
	
	
	
	     
		
	}
	
	
	}
	
	}
	

	
	

