package java_test;
import java.util.Scanner;
public class oneTick {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner input = new Scanner(System.in) ;

System.out.println("��J�����N�X'");
System.out.println("��J�ƶq");
int num1=input.nextInt();
int num2 = input.nextInt();
if(num1==1){
	System.out.printf("total",3000*num2);

}

	
	
	
	
	}

}
