package java_test;

import java.util.Scanner;

public class pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int num = input.nextInt();
System.out.println("Please enter a number:" +num);
System.out.println("your square looks like:" ) ;

		
		
		
		
		
		
		for (int i = 0; i <= num; i++) {

		for (int j = 0; i <= num; j++) {
			System.out.printf("*");
		
		}
	}

}}