package java_test;

public class checkNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
