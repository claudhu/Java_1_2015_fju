package java_test;

public class Lotteery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
