package exam;

public class PerfectNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("The perfect numbers that are less than 10000 are:");

	}

}
