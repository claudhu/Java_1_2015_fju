package exam;

public class exam_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
