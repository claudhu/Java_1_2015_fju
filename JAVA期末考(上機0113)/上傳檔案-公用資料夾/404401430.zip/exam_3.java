package exam;

import java.util.Scanner;

public class exam_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		
		System.out.print("�п�J�@�ӳ�r�A�˴���O�_���^��?");
		long voc =input.nextLong();
		
		System.out.println(voc);

	}

}
