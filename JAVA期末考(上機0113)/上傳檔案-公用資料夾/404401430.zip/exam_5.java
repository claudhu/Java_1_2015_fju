package exam;

import java.util.Scanner;

public class exam_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double score[][]=new double [4][2];
		

	}

}
