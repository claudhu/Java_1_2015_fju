package test;

import java.util.Arrays;

public class array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int[]i={20,8,7,50,30,90,78,15,12,100,7};
    
      Arrays.sort(i);
      System.out.println(i);
      
      
      
	}

}
