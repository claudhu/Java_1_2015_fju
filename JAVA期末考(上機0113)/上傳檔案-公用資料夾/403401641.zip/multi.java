package fju403401641;

public class multi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int array[][]={
		{78,100};
		{59,80};
		{90,70};
		{65,120};
};
	double fo)
	
	
	}

}
