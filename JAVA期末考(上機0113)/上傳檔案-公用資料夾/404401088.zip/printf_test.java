import java.util.Scanner;
public class printf_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		System.out.print("�M��J���");
		System.out.printf("");
		System.out.printf("");
		
		
	}

}
