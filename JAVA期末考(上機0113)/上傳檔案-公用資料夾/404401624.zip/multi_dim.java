package multi_dim;
import java.util.Scanner;
public class multi_dim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
	Scanner input = new Scanner(System.in);
	
    
    SelectionSearch(90,70);
    
	}
	
	public static void SelectionSearch(int i, int j) {
		double average = (i + j)/2;
		System.out.println(average);
	}
	

}
