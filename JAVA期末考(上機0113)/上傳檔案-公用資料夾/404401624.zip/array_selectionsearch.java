package array;
import java.util.Scanner;
public class array_selectionsearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
	Scanner input = new Scanner(System.in);
	
	int num[] = new int[10];
	
	
		
		
	}

}
