package array;
import java.util.Scanner;
public class linearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner input = new Scanner(System.in);
    
    int num[] = new int[10];
    num[1] = 20;
    num[2] = 8;
    num[3] = 7;
    num[4] = 50;
    num[5] = 30;
    num[6] = 90;
    num[7] = 78;
    num[8] = 15;
    num[9] = 12;
    num[10] = 100;
    num[11] = 7;
    
    
	}

}
