package java;
import java.util.Scanner;
public class print_testjava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner input = new Scanner(System.in);

System.out.println("�п�J8�Ӿ��");

for(int i =0;i<4;i++);

String a=input.nextLine();






	}

}
