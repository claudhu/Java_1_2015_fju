package java;
import java.util.Scanner;
public class arrayjava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("�ݭn87878787878787��");
	}

}
