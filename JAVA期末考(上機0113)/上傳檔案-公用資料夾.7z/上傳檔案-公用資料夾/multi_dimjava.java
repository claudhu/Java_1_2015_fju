package java;

public class multi_dimjava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
